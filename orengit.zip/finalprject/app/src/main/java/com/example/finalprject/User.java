package com.example.finalprject;

public class User {

        private String password;
        private String userName;
        private String Email;

        public User(String password, String name, String score) {
            this.password = password;
            this.userName = name;
            this.Email = score;
        }

        public String getPassword() {
            return password;
        }

        public String getUserName() {
            return userName;
        }

        public String getEmail() {
            return Email;
        }

    public void setEmail(String email) {
        Email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    }








